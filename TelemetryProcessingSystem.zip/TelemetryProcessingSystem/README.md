﻿# TelemetryProcessingSystem

High-performance telemetry data processing system for manufacturing environments.

## Project Structure

- **core/** - Core telemetry processing engine
- **modules/** - Modular processing pipeline (ingestion, transformation, analytics, export)
- **third_party/** - External dependencies (Boost, Protobuf, Custom SDK)
- **tests/** - Unit and integration tests
- **config/** - Configuration files and environment settings
- **docs/** - Architecture and API documentation
- **tools/** - Diagnostic and performance analysis tools
- **resources/** - Schemas and templates

## Prerequisites

- Visual Studio 2022 with C++ workload
- CMake >= 3.21
- C++17 compatible compiler
- Boost library (headers and system/filesystem)
- Protocol Buffers (protobuf)
- GoogleTest (for running tests)
- Git

## Quick Start

### 1. Clone Repository
\\\ash
git clone <repo-url> TelemetryProcessingSystem
cd TelemetryProcessingSystem
\\\

### 2. Bootstrap Dependencies (vcpkg)
\\\powershell
.\scripts\bootstrap_vcpkg.ps1
\\\

### 3. Configure with CMake
\\\ash
cmake --preset vs2022-x64-debug
\\\

### 4. Build
\\\ash
cmake --build --preset debug
\\\

### 5. Run Tests
\\\ash
ctest --preset default
\\\

## Building in Visual Studio

1. **File > Open > Folder...** and select the project root
2. **CMake > Change CMake Settings** to select desired preset
3. **Build > Build All** or press **Ctrl+Shift+B**

## Configuration

Edit configuration files in \config/\:
- \ppsettings/\ - Application settings
- \logging/\ - Logging configuration
- \environments/\ - Environment-specific configs

## Troubleshooting

### Missing Headers
Ensure THIRD_PARTY_ROOT is set correctly and CMake finds Boost/Protobuf.

### Linker Errors
Verify CMAKE_TOOLCHAIN_FILE points to vcpkg and dependencies are linked in CMakeLists.txt.

### Build Failures
Check build/output/debug/CMakeOutput.log for detailed error messages.

## Documentation

- See \docs/architecture/\ for system design
- See \docs/api/\ for API reference

## Support

Contact the development team or refer to the latest documentation.
