﻿#pragma once

#include <memory>
#include <vector>

namespace TelemetryProcessingSystem {

class IDataHandler {
public:
    virtual ~IDataHandler() = default;
    virtual void Handle(const std::vector<uint8_t>& data) = 0;
};

}  // namespace TelemetryProcessingSystem
