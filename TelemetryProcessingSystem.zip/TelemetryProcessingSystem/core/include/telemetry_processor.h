﻿#pragma once

#include <memory>
#include <vector>
#include <string>

namespace TelemetryProcessingSystem {

class TelemetryProcessor {
public:
    TelemetryProcessor();
    ~TelemetryProcessor();

    void Initialize(const std::string& config_path);
    void ProcessData(const std::vector<uint8_t>& data);
    void Shutdown();

private:
    bool is_initialized_;
};

}  // namespace TelemetryProcessingSystem
