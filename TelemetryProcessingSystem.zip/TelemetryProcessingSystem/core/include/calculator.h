﻿#pragma once
#include <vector>
#include <cmath>
#include <stdexcept>
namespace TelemetryProcessingSystem {
class Calculator {
public:
    Calculator();
    ~Calculator();
    double Sum(const std::vector<double>& values) const;
    double Average(const std::vector<double>& values) const;
    double Minimum(const std::vector<double>& values) const;
    double Maximum(const std::vector<double>& values) const;
    double StandardDeviation(const std::vector<double>& values) const;
    double Variance(const std::vector<double>& values) const;
    double Median(std::vector<double> values) const;
    double Add(double a, double b) const;
    double Subtract(double a, double b) const;
    double Multiply(double a, double b) const;
    double Divide(double a, double b) const;
    double Percentage(double value, double percentage) const;
    double Absolute(double value) const;
    double Power(double base, double exponent) const;
    double SquareRoot(double value) const;
private:
    void ValidateNonEmpty(const std::vector<double>& values, const std::string& operation_name) const;
};
}
