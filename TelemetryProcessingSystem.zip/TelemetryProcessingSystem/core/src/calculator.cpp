﻿#include "../include/calculator.h"
#include <algorithm>
#include <numeric>
#include <sstream>
namespace TelemetryProcessingSystem {
Calculator::Calculator() { }
Calculator::~Calculator() { }
void Calculator::ValidateNonEmpty(const std::vector<double>& values, const std::string& operation_name) const {
    if (values.empty()) {
        std::string error_msg = operation_name + ": Input vector cannot be empty";
        throw std::invalid_argument(error_msg);
    }
}
double Calculator::Sum(const std::vector<double>& values) const {
    ValidateNonEmpty(values, "Sum");
    return std::accumulate(values.begin(), values.end(), 0.0);
}
double Calculator::Average(const std::vector<double>& values) const {
    ValidateNonEmpty(values, "Average");
    return Sum(values) / values.size();
}
double Calculator::Minimum(const std::vector<double>& values) const {
    ValidateNonEmpty(values, "Minimum");
    return *std::min_element(values.begin(), values.end());
}
double Calculator::Maximum(const std::vector<double>& values) const {
    ValidateNonEmpty(values, "Maximum");
    return *std::max_element(values.begin(), values.end());
}
double Calculator::Variance(const std::vector<double>& values) const {
    ValidateNonEmpty(values, "Variance");
    if (values.size() < 2) {
        throw std::invalid_argument("Variance: Vector must contain at least 2 elements");
    }
    double mean = Average(values);
    double sum_squared_diff = 0.0;
    for (double value : values) {
        double diff = value - mean;
        sum_squared_diff += diff * diff;
    }
    return sum_squared_diff / (values.size() - 1);
}
double Calculator::StandardDeviation(const std::vector<double>& values) const {
    ValidateNonEmpty(values, "StandardDeviation");
    if (values.size() < 2) {
        throw std::invalid_argument("StandardDeviation: Vector must contain at least 2 elements");
    }
    return std::sqrt(Variance(values));
}
double Calculator::Median(std::vector<double> values) const {
    ValidateNonEmpty(values, "Median");
    std::sort(values.begin(), values.end());
    size_t size = values.size();
    if (size % 2 == 0) {
        return (values[size / 2 - 1] + values[size / 2]) / 2.0;
    } else {
        return values[size / 2];
    }
}
double Calculator::Add(double a, double b) const { return a + b; }
double Calculator::Subtract(double a, double b) const { return a - b; }
double Calculator::Multiply(double a, double b) const { return a * b; }
double Calculator::Divide(double a, double b) const {
    if (b == 0.0) {
        throw std::invalid_argument("Divide: Division by zero is not allowed");
    }
    return a / b;
}
double Calculator::Percentage(double value, double percentage) const {
    if (percentage < 0.0 || percentage > 100.0) {
        throw std::invalid_argument("Percentage: Percentage must be between 0 and 100");
    }
    return (value * percentage) / 100.0;
}
double Calculator::Absolute(double value) const { return std::abs(value); }
double Calculator::Power(double base, double exponent) const { return std::pow(base, exponent); }
double Calculator::SquareRoot(double value) const {
    if (value < 0.0) {
        throw std::invalid_argument("SquareRoot: Cannot calculate square root of negative number");
    }
    return std::sqrt(value);
}
}
